
def ingreso_pedido_cliente(info_clientes:dict,menu_panaderia:list) -> dict:
    cliente_exsistente = input("Usted ya es cliente? (si/no): ")
    if cliente_exsistente == "si":
        seguir = "si"
        while seguir == "si":
            dni = int(input("Ingrese el numero de dni: "))
            nombre = info_clientes[dni][0]
            apellido = info_clientes[dni][1]
            pedido = input("Que pidio?: ")
            deuda = menu_panaderia[pedido][0]
            cantidad = menu_panaderia[pedido][1] + 1
            seguir = input("Desea continuar ingresando pedidos? (si/no): ")
    else:
        seguir = "si"
        while seguir == "si":
            dni = int(input("Ingrese su DNI: "))
            nombre = input("Nombre: ")
            apellido = input("Apellido: ")
            pedido = input("Que pidio?: ")
            deuda = menu_panaderia[pedido][0]
            cantidad = menu_panaderia[pedido][1] + 1
            seguir = input("Desea continuar ingresando pedidos? (si/no): ")
    print("MUchas Gracias, su pedido fue realizado.")
        
    info_clientes[dni] = [nombre,apellido,deuda]
    menu_panaderia[pedido][1] = cantidad

    return info_clientes,menu_panaderia

def ingreso_pago(info_clientes:dict) -> dict:
    dni = input("Ingrese el numero de dni: ")
    print(f"La deuda es de {info_clientes[dni][2]} pesos.")
    pago = int(input("Cuanto pago?: "))
    deuda = info_clientes[dni][2] - pago
    info_clientes[dni][2] = deuda
    return info_clientes

def buscar_mayores_deudas(info_clientes:dict) -> list:
    deudores_maximos = list()
    info_clientes1 = info_clientes.copy()
    for i in range(4):
        maximo = max(info_clientes1)
        deudores_maximos = deudores_maximos.append(maximo)
        ubicacion_del_maximo = info_clientes1.index(maximo)
        info_clientes1 = info_clientes1.pop(ubicacion_del_maximo)
    pass


def reporte_cantidad_pedidos_por_articulo(menu_panaderia:dict) -> str:
    for clave, valor in menu_panaderia.items():
        print(f"{clave} - {valor[1]} pedidos.")    

def main() -> None:
    menu_panaderia = {"Baguette_Clasica":[250,2],"Baggette_Rellena":[250,4],"Baggette_Vegana":[250,7],"Baggette_con_Muzzarella":[500,0],"Merlot":[300,2],"Vin_Rose":[300,0],"Borgoña_blanc":[550,0]}
    info_clientes = {44254782:["Francisco","Sobral",0],21002041:["Juan","Miguens",500]}
    print( """
    a. Ingresar pedidos por cliente.
    b. Ingresar pago de pedidos de un cliente.
    c. Top 5 de las deudas más importantes. 
    d. Reporte de pedidos solicitados por articulo.
    e. Indicar el porcentaje de pedidos superiores a $1000.
    """)
    eleccion = input("Que accion desea realizar?: ")

    if eleccion == "a":
        info_clientes = ingreso_pedido_cliente(info_clientes,menu_panaderia)
    elif eleccion == "b":
        info_clientes = ingreso_pago(info_clientes)
    elif eleccion == "c":
        #funcion c
        pass
    elif eleccion == "d":
        reporte_cantidad_pedidos_por_articulo(menu_panaderia)
        pass
    elif eleccion == "e":
        #funcion e
        pass
main()
